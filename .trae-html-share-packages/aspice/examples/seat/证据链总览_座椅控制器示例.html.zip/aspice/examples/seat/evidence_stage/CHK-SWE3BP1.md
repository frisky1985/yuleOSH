---
artifact: CHK-SWE3BP1__compliance
stage: review
verdict: 通过
result: 通过
evidence_loc: evidence_stage/compliance_raw.json#SWE.3.BP1
fills:
  - SUP.1_评审记录::CHK-SWE3BP1::结果(通过·不通过·不适用)
  - SUP.1_评审记录::CHK-SWE3BP1::证据位置
---

# 示例数据 · 不得作为项目证据

# CHK-SWE3BP1（SWE.3.BP1 Develop detailed design）合规评审记录

- 判定：通过
- 依据：全部检查项通过
- 原始报告：evidence_stage/compliance_raw.json 节点 SWE.3.BP1

> 真实 yuleOSH pipeline 输出（ComplianceChecker, ASPICE v3.1, 18 BP），
> 由 adapter_compliance.py 适配为证据链产物。
